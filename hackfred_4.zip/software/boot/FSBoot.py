 # Copyright (C) 2020 FS, LTD. All Rights Reserved.
 #
 # This document is the property of FS LTD.
 #
 # It is considered proprietary and confidential.
 #
 # This document may not be reproduced or transmitted in any form,
 # in whole or in part, without the written permissions of FS OSDT,
 # or associated bodies.

#Imports time functions.
from random import random
import threading
import time


#Imports OS version from system.
from os import system, name

#Imports Sleep
from time import sleep

#Defines Clear Function.
def clear():

    if name == 'nt':
        _ = system('cls')

    else:
        _ = system('clear')

boot = 'No'
BootKey = str('3294414646')
syscmd = str('1')

result = None

#Displays the loading animation.
for x in range(0,25):
  print("/ Loading")
  time.sleep(0.1)
  clear()
  print("- Loading")
  time.sleep(0.1)
  clear()
  print("| Loading")
  time.sleep(0.1)
  clear()

time.sleep(4)

#Starts the FSBoot Script.
print("Starting fOS...")
time.sleep(4)
print("")
print("fOS Version 13.0.0, FRED-OS Version 14.0.0")
time.sleep(2)
print("")
print("Verifying BootKey()...")
time.sleep(4)
print("")
#Checks if the BootKey() is correct.
if BootKey == '3294414646':
  #If it is correct:
  print("BootKey() has been verified.")
  print("")
  boot = 'Yes'
else:
  #If it is not correct:
  print("An incorrect boot key was provided, which means that your device has been modified extensively by yourself or a third-party, and/or the version of fOS is not a genuine FS build.")
  exit()
#Continues the FSBoot Script.
print("Checking boot files in")
print("{C:\FOS\SOFTWARE\BOOT\...}") # Checks the files in the "Boot" Folder.
time.sleep(1)
print("")
print("Done.")
print("")
time.sleep(0.8)
if boot == 'Yes':
 #Loads the files for booting.
 print("Correct bootable files found, booting fOS...")
 time.sleep(3)
 print("")
 print("Loaded: C:\FOS\SOFTWARE\BOOT\FSBOOT.xml")
 time.sleep(0.1)
 print("Loaded: C:\FOS\SOFTWARE\BOOT\RUNBOOT.fsf")
 time.sleep(0.1)
 print("Loaded: C:\FOS\SOFTWARE\BOOT\BootOrder.sys")
 time.sleep(0.1)
 print("Loaded: C:\FOS\SOFTWARE\BOOT\StartupApplications.sys")
 time.sleep(0.1)
 print("Loaded: C:\FOS\SOFTWARE\BOOT\BootOrder004.sys")
 time.sleep(0.1)
 print("Loaded: C:\FOS\SOFTWARE\BOOT\BootOrder0.sys")
 time.sleep(0.1)
 print("Loaded: C:\FOS\SOFTWARE\BOOT\BootOrder1.sys")
 time.sleep(0.1)
 print("Loaded: C:\FOS\SOFTWARE\BOOT\BootOrder2.sys")
 time.sleep(0.1)
 print("Loaded: C:\FOS\SOFTWARE\BOOT\BootOrder3.sys")
 time.sleep(0.1)
 print("Loaded: C:\FOS\SOFTWARE\BOOT\BootOrder4.sys")
 time.sleep(0.1)
 print("Loaded: C:\FOS\SOFTWARE\BOOT\BootOrder5.sys")
 time.sleep(0.1)
 print("Loaded: C:\FOS\SYSTEM\LOGON\FOSLogon.fsf")
 time.sleep(0.1)
 print("Loaded: C:\FOS\SYSTEM\LOGON\FOSLogon.lib")
 time.sleep(0.1)
 print("Loaded: C:\FOS\SYSTEM\LOGON\FOSUsers.fsf")
 time.sleep(0.1)
 print ("Loaded: C:\FOS\SYSTEM\LOGON\FOSUsers.lib")
 time.sleep(0.1)
 print ("Loaded: C:\FOS\SYSTEM\DRIVERS\Display.fsd")
 time.sleep(0.1)
 print ("Loaded: C:\FOS\SYSTEM\DRIVERS\Speakers.fsd")
 time.sleep(0.1)
 time.sleep(0.1)
 print ("Loaded: C:\FOS\SYSTEM\DRIVERS\Keyboard.fsd")
 time.sleep(0.1)
 print ("Loaded: C:\FOS\SYSTEM\DRIVERS\Mouse.fsd")
 time.sleep(0.1)
 print ("Loaded: C:\FOS\SYSTEM\DRIVERS\Fredcam.fsd")
#If correct boot files aren't present:
elif boot == 'No':
  print("Failure booting. Correct boot files were not present in the source folder. Please restart and try again.")
  exit()

#Loads the logon services for displaying.
print("")
time.sleep(5)
print("Loading fOS Logon Service {FOSLogon.fsf}")
time.sleep(0.3)
print("Loading fOS Logon Application Extention {FOSLogon.lib}")
time.sleep(0.3)
print("Loading fOS Users {FOSUsers.fsf}")
time.sleep(0.3)
print("Loading fOS Users Application Extention {FOSUsers.lib}")
time.sleep(0.5)
print("")
print("Done.")
time.sleep(1)
print("")

#Logon Service:
uname = str(input("Username: "))
pswd = str(input("Password: "))

time.sleep(2)

if uname == 'admin':
  if pswd == '':
   print("")
   startcmd = str(input("\ADMIN\> "))
   if startcmd == 'FOS':
     time.sleep(3)
     print("")
     time.sleep(0.2)
     print("")
     time.sleep(0.2)
     print("")
     time.sleep(0.2)
     time.sleep(3)
     clear()
     print("// desktop //")
     time.sleep(10)
     clear()
     exit()
    # import webbrowser
#url = 'file:///path/to/your/file/testdata.html'
#webbrowser.open(url, new=2)  # open in new tab
   else:
    print ("Command not recognised. Ending Session...")
    time.sleep(2)
    clear()
  else:
   print("Password is incorrect.")
elif uname == 'system':
  if pswd == '':
   print("")
   startcmd = str(input("\SYSTEM\> "))
   if startcmd == 'FOS':
     time.sleep(3)
     print("")
     time.sleep(0.2)
     print("")
     time.sleep(0.2)
     print("")
     time.sleep(0.2)
     time.sleep(3)
     clear()
     while syscmd != 'terminatex':
       syscmd = str(input("C:\> "))
       if syscmd == 'ver':
           print("fOS 10.15.00 (Build xxxx)")
     print("")
     time.sleep(0.3)
     print("")
     time.sleep(0.3)
     print("Ending fOS Session...")
     time.sleep(5)
     print("")
     clear()
     exit()

#If unknown user entered:
else:
  print(uname + " is not a registered user account.")
