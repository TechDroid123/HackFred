function pkey() {
    var value = document.getElementById("pkey").value;
    if (value == "XqRN-NrCW-LR0i-Uzps-ZKA5") {
        location.href = '0012.html';
    } else {

    }
}
