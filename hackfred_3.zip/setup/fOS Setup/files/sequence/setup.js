// (C) 2020 FS OSDT.<script type="text/javascript">
document.addEventListener('contextmenu', event => event.preventDefault());
